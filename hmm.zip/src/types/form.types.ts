interface AttendeeFormHeaderProps {
	formProgress: number;
}

interface AttendeeFormProps {
	formProgress: number;
	setFormProgress: (formProgress: number) => void;
}
