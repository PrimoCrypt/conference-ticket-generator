import React from "react";
import SelectTicket from "./SelectTicket";

const AttendeeForm = ({ formProgress, setFormProgress }: AttendeeFormProps) => {
	let form;
	switch (formProgress) {
		case 33:
			form = <SelectTicket setFormProgress={setFormProgress} />;
			break;
		default:
			form = <SelectTicket setFormProgress={setFormProgress} />;
	}
	return <div>{form}</div>;
};

export default AttendeeForm;
