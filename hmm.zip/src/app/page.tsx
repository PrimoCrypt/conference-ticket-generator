"use client";
import React, { useState } from "react";
import AttendeeFormHeader from "./_components/AttendeeFormHeader";
import AttendeeForm from "./_components/AttendeeForm";

const Page = () => {
	const [formProgress, setFormProgress] = useState<number>(33);
	return (
		<div className="border border-solid rounded-[3rem] border-primary bg-[#041E23] p-12 flex flex-col gap-8 w-[700px]">
			<AttendeeFormHeader formProgress={formProgress} />
			<AttendeeForm setFormProgress={setFormProgress} formProgress={formProgress} />
		</div>
	);
};

export default Page;
