import React from "react";

const AttendeeFormHeader = ({ formProgress }: AttendeeFormHeaderProps) => {
	return (
		<div className="text-white flex flex-col w-full gap-3">
			<section className="flex justify-between items-center">
				<h3 className="text-[2rem] leading-8 tracking-normal w-full">Ticket Selection</h3>
				<p className="text-nowrap font-r">Step {formProgress === 33 ? 1 : formProgress === 66 ? 2 : 3}/3</p>
			</section>
			<section className="w-full bg-[#0E464F] h-1">
				<div style={{ width: `${formProgress}%` }} className={` bg-[#24A0B5] h-1`}></div>
			</section>
		</div>
	);
};

export default AttendeeFormHeader;
